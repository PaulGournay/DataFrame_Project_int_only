CDataframe by Paul GOURNAY and Vrej KARAKOZIAN, INT-1
Note that we ave two github one with integer only and the other with all data types

CDataframe is a simple C library for working with tabular data. It allows you to create, manipulate, and analyze data. 

## Features(for the moment)
- Create a column with a specified title.
- Insert values into a column.
- Delete a column.
- Print the values of a column.
- Find the occurrence of a value in a column.
- Get the value at a specific index in a column.
- Count the number of values greater than and lower than a specified value in a column.

Link to the github: https://github.com/PaulGournay/DataFrame_Project_int_only.git
